package com.example.alara;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.media.Image;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.example.retrofit.*;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Main_App extends AppCompatActivity {

    private TextView textviewResult;
    private ImageView fotoImagen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__app);
        fotoImagen=(ImageView) findViewById(R.id.fotoImage);
        textviewResult=findViewById(R.id.text_view_result);
        Retrofit retrofit= new Retrofit.Builder()
                .baseUrl("https://rocky-fjord-18899.herokuapp.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        JsonPlaceHolderApi jsonPlaceHolderApi=retrofit.create(JsonPlaceHolderApi.class);
        Call<List<Cancion>> call=jsonPlaceHolderApi.getCancion();
        call.enqueue(new Callback<List<Cancion>>() {
            @Override
            public void onResponse(Call<List<Cancion>> call, Response<List<Cancion>> response) {
                if(!response.isSuccessful()){
                    textviewResult.setText("Code:"+response.code());
                    return ;
                }
                List<Cancion>canciones=response.body();
                for(Cancion cancion:canciones){
                    String content="";
                    content+=cancion.getNombre()+"\n";
                    Glide.with(Main_App.this)
                            .load(cancion.getUrl())
                            .into(fotoImagen);

                    textviewResult.append(content);
                }

            }

            @Override
            public void onFailure(Call<List<Cancion>> call, Throwable t) {
                textviewResult.setText(t.getMessage());
            }
        });
    }
}
